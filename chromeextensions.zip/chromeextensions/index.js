let myleads=[]
const inputel=document.getElementById("input-el")


const inputbtn=document.getElementById("input-btn")
const ulel=document.getElementById("ul-el")


inputbtn.addEventListener("click",function(){
    myleads.push(inputel.value)
    //console.log(inputel.value)
    inputel.value=""
    renderleads()


})
function renderleads(){
let listiteams=""
for (let i=0;i<myleads.length;i++)
{
   // listiteams+="<li><a target='_blank' href=' "+ myleads[i] +"'>" + myleads[i] + "</a></li>"
   listiteams+=`
        <li>
            <a target='_blank' href=' ${myleads[i]}'>
               ${myleads[i]}
            </a>
        </li>
   `

}
ulel.innerHTML=listiteams
}